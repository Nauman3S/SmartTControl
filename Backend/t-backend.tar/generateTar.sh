rm -rf t-backend.tar
tar -cvf t-backend.tar *
