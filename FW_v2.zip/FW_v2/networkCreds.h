// Your GPRS credentials, if any

const char gprsUser[] = "";
const char gprsPass[] = "";
// set GSM PIN, if any
#define GSM_PIN ""