


#include <Wire.h>
#define MODEM_RST             5
#define MODEM_PWRKEY          4
#define MODEM_POWER_ON       23
#define MODEM_TX             27
#define MODEM_RX             26
#define PIN_DTR     25



// #define MODEM_RST             5
// #define MODEM_PWRKEY          4
// #define MODEM_POWER_ON       23
// #define MODEM_TX             27
// #define MODEM_RX             26

// #define I2C_SDA              21
// #define I2C_SCL              22
// #define LED_GPIO             13
// #define LED_ON               HIGH
// #define LED_OFF              LOW

// #define IP5306_ADDR          0x75
// #define IP5306_REG_SYS_CTL0  0x00

